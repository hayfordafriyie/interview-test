## Interview

An interview app UI interaction built in flutter.

![HomePage](./pictures/interview.jpg)

# Build Image

![HomePage](./pictures/build.jpg)

# Run

```bash
flutter run
```

**Developer:** Tolulope Fakunle
**Email:** fakunletolulope05@gmail.com


