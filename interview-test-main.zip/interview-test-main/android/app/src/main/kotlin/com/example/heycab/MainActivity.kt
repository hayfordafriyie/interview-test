package com.example.interview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
